TheRealFrescobar Discovery Page
================================

Open TheRealFrescobar_Discovery_Final.html in a browser to preview the page.
The main buttons link to the TikTok profile:
https://www.tiktok.com/@therealfrescobar

To publish it, upload the HTML file to a static website host or your existing website.
The game tiles currently open TikTok searches; replace those links with direct video URLs
when you have specific clips you want visitors to watch.
